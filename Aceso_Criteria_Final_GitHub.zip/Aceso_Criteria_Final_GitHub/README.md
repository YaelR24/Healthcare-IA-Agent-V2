# Aceso Intelligence — Criteria Final

This package contains only the source changes required for the final Criteria experience. It does not include or replace Knowledge Base, Today, Pipeline, Dashboard, Proposal Copilot, or any other section of Aceso Intelligence.

## Included

- `files/dist/final-round.js` — current source file containing the final Criteria logic and interactions.
- `files/dist/styles.css` — current stylesheet containing the final Criteria presentation.
- `files/dist/assets/coefficient-giving.png` — local source logo used by Sources & Monitoring.
- `files/dist/assets/unitaid.png` — local source logo used by Sources & Monitoring.
- `patches/aceso-criteria-final.patch` — binary-safe Git patch containing only the Criteria changes made in the independent review copy.
- `CHECKSUMS.txt` — SHA-256 checksums for verification.

## Recommended GitHub integration

The safest option is to apply the patch from the root of the target repository:

```bash
git checkout -b feature/criteria-final
git apply --check patches/aceso-criteria-final.patch
git apply patches/aceso-criteria-final.patch
```

Then review the four changed paths and commit them:

```bash
git status
git add dist/final-round.js dist/styles.css dist/assets/coefficient-giving.png dist/assets/unitaid.png
git commit -m "Integrate final Criteria experience"
```

If the target repository has changed substantially and the patch cannot be applied cleanly, use the files under `files/` for comparison and manual integration. Do not blindly replace files if the target branch contains newer work in the same files.

## Functional in this prototype

- Five-page Criteria notebook navigation.
- Agent / Human explanation switch.
- Add, edit, enable/disable, and remove criteria values.
- Editable focus areas, activities, keywords, geographies, funders, exclusions, languages, and review flags.
- Editable budget and deadline thresholds.
- Local Coefficient Giving and Unitaid source logos.
- Responsive Criteria layout.

## Prototype-only or not connected

- Changes are held in the current browser session only.
- Save and reset actions show prototype feedback but do not persist to a backend.
- Criteria are not connected to the live evaluation engine.
- Source cards describe intended monitoring sources; they are not live integrations.
- Opportunity scoring is not recalculated from these controls in this package.

## Important scope note

`final-round.js` and `styles.css` are supplied as complete current files because Criteria is embedded in those existing application files. The Git patch is the preferred artifact when integrating only this section.
